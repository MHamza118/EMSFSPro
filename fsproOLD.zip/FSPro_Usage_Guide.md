# FSPro Employee Management System - Usage Guide

## 📋 Core Functionalities

### 🏢 System Overview
FSPro is an employee management system for attendance tracking, schedule management, and employee monitoring.

**User Roles:**
- **Employee**: Check-in/out, view attendance, manage timetable
- **Admin**: Full system access, employee management, attendance oversight

### 🔐 Authentication
- Login with registered email and password
- Remember Me option for session persistence
- Mobile-responsive interface

### ⏰ Check-In & Check-Out Usage

#### **Regular Check-In:**
- **Available**: 1 hour before to 30 minutes after scheduled time
- **Action**: Click "Regular Check-in" button
- **Requirements**: Must have active timetable schedule
- **Result**: Normal attendance record created

#### **Late Check-In:**
- **Activated**: Automatically when more than 30 minutes late
- **Time Window**: 30 minutes to 2 hours after scheduled time
- **Action**: Click "Late Check-in" button
- **Requirements**: Mandatory reason must be provided
- **Result**: Late attendance record + admin notification

#### **Regular Check-Out:**
- **Available**: After completing minimum scheduled hours
- **Action**: Click "Regular Check-out" button
- **Requirements**: Must have active check-in session
- **Result**: Session completed, working hours calculated

#### **Late Check-Out:**
- **Activated**: When working beyond scheduled end time
- **Action**: Click "Late Check-out" button
- **Requirements**: No reason required
- **Result**: Overtime hours recorded for compensation

#### **System Behavior:**
- **Button Availability**: System automatically shows/hides appropriate buttons
- **Time Validation**: Real-time checking of allowed windows
- **Duplicate Prevention**: 10-minute cooldown between attempts
- **Status Display**: Current check-in/out status clearly shown

### ⏱️ Time Validation Windows

#### **Regular Check-In Window:**
- Opens 1 hour before scheduled time
- Closes 30 minutes after scheduled time

#### **Late Check-In Window:**
- Opens 30 minutes after scheduled time
- Closes 2 hours after scheduled time
- Requires mandatory reason

#### **Restrictions:**
- 10-minute cooldown between check-in attempts
- Multiple time slots per day supported
- Sequential slot processing required

### 📅 Timetable Management

#### **Employee Schedule Setup:**
- Access "My Timetable" section
- Add work slots with check-in/check-out times (24-hour format)
- Support for multiple slots per day
- Edit or remove existing slots

#### **Key Restrictions:**
- **Current week lock**: Cannot modify current week's schedule
- **Weekly reset**: Schedule resets every Monday
- **Admin override**: Administrators can modify any schedule
- **Future planning**: Set next week's schedule in advance

#### **Schedule Modification:**
- **Current week**: Contact administrator for changes
- **Future weeks**: Direct modification allowed
- Mobile-responsive interface for all devices

### 👨‍💼 Admin Features

#### **Attendance Management:**
- Real-time employee attendance monitoring
- Color-coded status indicators (green/yellow/red)
- Working hours calculation and overtime tracking
- Export capabilities for payroll reports

#### **Employee Management:**
- Override any employee schedule
- Bulk schedule updates
- Manual attendance corrections
- Generate disciplinary reports

### 🔔 Notifications System

#### **Employee Notifications:**
- Timetable change alerts
- System announcements
- Real-time action feedback

#### **Admin Notifications:**
- Immediate late check-in alerts
- Daily attendance summaries
- System monitoring updates

### 🔧 Common Issues

#### **Check-in Problems:**
- **"Window not open"**: Wait until 1 hour before scheduled time
- **"Multiple check-ins not allowed"**: Wait 10 minutes between attempts
- **"No more slots"**: Contact admin for additional hours
- **"Late window expired"**: Contact administrator for manual entry

#### **System Issues:**
- Clear browser cache for display problems
- Refresh page if buttons unresponsive
- Check internet connection for real-time updates
- Contact IT support for persistent issues

### 📞 Support
Contact your system administrator for technical issues or questions.
