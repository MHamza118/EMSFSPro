# FSPro Attendance System - Comprehensive Guide

## 📋 Table of Contents
1. [Check-In & Check-Out System](#check-in--check-out-system)
2. [Time Validation Windows](#time-validation-windows)
3. [Late Check-In Process](#late-check-in-process)
4. [Late Check-Out Process](#late-check-out-process)
5. [Timetable Management](#timetable-management)
6. [System Validations & Restrictions](#system-validations--restrictions)
7. [Troubleshooting](#troubleshooting)

---

## ⏰ Check-In & Check-Out System

### 🎯 Regular Check-In Process

#### **When Regular Check-In is Available:**
- **Time Window**: 1 hour before to 30 minutes after scheduled time
- **Example**: If scheduled at 9:00 AM
  - Available from: 8:00 AM
  - Available until: 9:30 AM
- **Button Status**: "Regular Check-in" button appears in green
- **Prerequisites**: Must have active timetable schedule set

#### **How to Perform Regular Check-In:**
1. **Access System**: Open FSPro on any device
2. **Navigate**: Go to Check-In/Out section
3. **Verify Time**: Ensure you're within the allowed window
4. **Click Button**: Press "Regular Check-in" button
5. **Confirmation**: System displays success message
6. **Record Created**: Attendance logged with timestamp

#### **What System Records:**
- Current date and exact time
- Employee ID and name
- Scheduled vs actual check-in time
- Working day information
- Session start confirmation

### 🎯 Regular Check-Out Process

#### **When Regular Check-Out is Available:**
- **Minimum Requirement**: Must complete scheduled working hours
- **Example**: If scheduled 9:00 AM - 5:00 PM, cannot check out before 5:00 PM
- **Button Status**: "Regular Check-out" button appears in red
- **Prerequisites**: Must have active check-in session

#### **How to Perform Regular Check-Out:**
1. **Complete Work**: Finish your scheduled hours
2. **Access System**: Open FSPro when ready to leave
3. **Verify Status**: Ensure you're checked in
4. **Click Button**: Press "Regular Check-out" button
5. **Confirmation**: System displays completion message
6. **Session Ended**: Working hours automatically calculated

#### **What System Calculates:**
- Total working hours for the session
- Break time deductions (if applicable)
- Overtime/undertime calculations
- Session completion status
- Daily attendance summary

---

## ⏱️ Time Validation Windows

### 🕐 Regular Check-In Window Details

#### **Window Opening Rules:**
- **Start Time**: Exactly 1 hour before scheduled check-in
- **Purpose**: Allows early arrival flexibility
- **System Behavior**: "Regular Check-in" button becomes active
- **Status Message**: "Check-in window is now open"

#### **Window Closing Rules:**
- **End Time**: Exactly 30 minutes after scheduled check-in
- **Purpose**: Reasonable lateness tolerance
- **System Behavior**: "Regular Check-in" button becomes disabled
- **Transition**: System automatically switches to late check-in mode

### 🕐 Late Check-In Window Details

#### **Window Activation:**
- **Start Time**: 30 minutes after scheduled check-in
- **Trigger**: Regular check-in window expires
- **System Behavior**: "Late Check-in" button appears (orange/red)
- **Status Message**: "Late check-in required - please provide reason"

#### **Window Duration:**
- **Maximum Lateness**: 2 hours after scheduled time
- **Example**: For 9:00 AM schedule, late window is 9:30 AM - 11:00 AM
- **Purpose**: Allows reasonable late arrivals with accountability
- **After Expiry**: System blocks check-in, requires admin intervention

### 🕐 Check-Out Validation Rules

#### **Minimum Work Time Validation:**
- **Rule**: Must work at least scheduled duration
- **Example**: 8-hour schedule requires minimum 8 hours worked
- **Early Check-Out**: Blocked unless admin approval
- **Break Consideration**: System accounts for scheduled breaks

#### **Late Check-Out Activation:**
- **Trigger**: Working beyond scheduled end time
- **No Maximum**: Can work as long as needed
- **Automatic Detection**: System recognizes overtime situation
- **Button Change**: "Late Check-out" option becomes available

---

## 🚨 Late Check-In Process

### 📋 When Late Check-In is Required

#### **Automatic Activation Scenarios:**
- **More than 30 minutes late**: System automatically switches modes
- **Example Scenarios**:
  - Scheduled: 9:00 AM, Arriving: 9:35 AM → Late check-in required
  - Scheduled: 14:00 PM, Arriving: 14:45 PM → Late check-in required
  - Scheduled: 8:00 AM, Arriving: 10:00 AM → Late check-in required

#### **System Behavior Changes:**
- **Regular Button**: Becomes disabled/grayed out
- **Late Button**: Appears in orange/red color
- **Status Message**: "You are X minutes late - late check-in required"
- **Reason Field**: Modal popup appears when clicked

### 📝 Late Check-In Step-by-Step Process

#### **Step 1: Recognize Late Status**
- **Visual Indicator**: Regular check-in button is disabled
- **Time Display**: Shows how many minutes/hours late
- **Message**: Clear indication that late check-in is required

#### **Step 2: Click Late Check-In Button**
- **Button Location**: Same area as regular check-in
- **Button Color**: Orange or red to indicate lateness
- **Button Text**: "Late Check-in" with warning icon

#### **Step 3: Provide Mandatory Reason**
- **Modal Popup**: Appears automatically
- **Text Field**: Large text area for reason entry
- **Character Limit**: Typically 200-500 characters
- **Requirement**: Cannot submit without reason

#### **Step 4: Submit Late Check-In**
- **Review**: Check reason for accuracy
- **Submit Button**: "Submit Late Check-in" button
- **Processing**: System validates and records
- **Confirmation**: Success message displayed

### 📧 Admin Notification System

#### **Automatic Alert Triggers:**
- **Immediate**: Sent as soon as late check-in is submitted
- **Recipients**: All system administrators
- **Priority**: High priority notification

#### **Notification Content Includes:**
- Employee name and ID
- Scheduled check-in time
- Actual check-in time
- Minutes/hours late
- Employee's provided reason
- Date and day of week
- Direct link to employee's attendance record

#### **Admin Dashboard Updates:**
- **Color Coding**: Late check-ins highlighted in red
- **Filter Options**: Admins can filter by late arrivals
- **Report Generation**: Late check-ins included in reports
- **Follow-up Tracking**: Admins can add notes or actions

### 📊 Late Check-In Consequences

#### **Attendance Record Impact:**
- **Permanent Marking**: Record permanently marked as "Late"
- **Time Tracking**: Working hours calculated from actual check-in time
- **Performance Metrics**: May affect attendance ratings
- **Historical Data**: Contributes to lateness pattern analysis

#### **Potential Follow-Up Actions:**
- **HR Review**: Frequent lateness may trigger HR discussion
- **Performance Review**: May be discussed in evaluations
- **Disciplinary Action**: Depends on company policy
- **Payroll Impact**: May affect pay depending on policy

---

## 🕐 Late Check-Out Process

### 📋 When Late Check-Out Occurs

#### **Overtime Scenarios:**
- **Project Deadlines**: Staying late to complete tasks
- **Emergency Work**: Unexpected urgent requirements
- **Voluntary Overtime**: Choosing to work additional hours
- **Management Request**: Asked to work beyond scheduled time

#### **System Detection:**
- **Automatic Recognition**: System detects when working past scheduled end
- **Button Activation**: "Late Check-out" option becomes available
- **No Time Limit**: Can work as long as needed
- **Flexible Timing**: Check out at any time during overtime

### 📝 Late Check-Out Step-by-Step Process

#### **Step 1: Work Beyond Scheduled Time**
- **Continue Working**: Past your scheduled end time
- **System Recognition**: Automatically detects overtime situation
- **Status Update**: Display shows you're in overtime

#### **Step 2: Access Late Check-Out**
- **Button Appearance**: "Late Check-out" button becomes visible
- **Button Color**: Usually blue or green (positive indicator)
- **No Restrictions**: Available immediately when overtime starts

#### **Step 3: Submit Late Check-Out**
- **Single Click**: No additional forms required
- **No Reason Needed**: Unlike late check-in, no explanation required
- **Instant Processing**: Immediate confirmation
- **Session Ended**: Overtime hours automatically calculated

### 💰 Overtime Calculation System

#### **Automatic Computation:**
- **Precise Tracking**: Calculated to the minute
- **Example Calculation**:
  - Scheduled: 09:00 - 17:00 (8 hours)
  - Actual: 09:00 - 18:30 (9.5 hours)
  - Regular Hours: 8 hours
  - Overtime: 1.5 hours

#### **Payroll Integration:**
- **Overtime Flagging**: Extra hours marked for compensation
- **Rate Calculation**: Often paid at premium rates (1.5x normal)
- **Report Generation**: Overtime data exported for payroll
- **Approval Tracking**: Some companies require overtime approval

### 🎯 Late Check-Out Benefits

#### **Employee Benefits:**
- **Compensation**: Overtime hours typically paid at premium
- **Flexibility**: Accommodates varying workloads
- **Project Completion**: Ensures tasks are finished properly
- **No Penalties**: Late check-out viewed positively

#### **Performance Indicators:**
- **Dedication Tracking**: Shows commitment to work
- **Reliability**: Demonstrates willingness to complete tasks
- **Adaptability**: Shows flexibility to business needs
- **Team Support**: Helps meet project deadlines

---

## 📅 Timetable Management

### 🔧 Setting Up Your Schedule

#### **Accessing Timetable Section:**
- **Navigation**: Go to "My Timetable" from dashboard
- **View**: Weekly calendar showing all 7 days
- **Interface**: User-friendly drag-and-drop or form-based entry
- **Mobile Support**: Fully responsive for mobile devices

#### **Adding Work Slots:**
- **Click "Add Slot"**: For any working day
- **Time Format**: Use 24-hour format (e.g., 09:00, 17:00)
- **Validation**: System checks for conflicts and overlaps
- **Save**: Click "Save" to confirm the slot

#### **Multiple Slots Per Day Examples:**

##### **Split Shift Schedule:**
- **Morning Slot**: 08:00 - 12:00 (4 hours)
- **Afternoon Slot**: 13:00 - 17:00 (4 hours)
- **Total**: 8 hours with 1-hour lunch break
- **Use Case**: Retail, customer service roles

##### **Part-Time Schedule:**
- **Session 1**: 09:00 - 13:00 (4 hours)
- **Session 2**: 15:00 - 18:00 (3 hours)
- **Total**: 7 hours with 2-hour break
- **Use Case**: Students, flexible workers

##### **Extended Day Schedule:**
- **Main Shift**: 08:00 - 16:00 (8 hours)
- **Evening Session**: 18:00 - 20:00 (2 hours)
- **Total**: 10 hours with 2-hour break
- **Use Case**: Project-based work

### ⚠️ Critical Timetable Restrictions

#### **Current Week Lock System:**
- **Restriction**: Cannot modify current week's schedule once set
- **Purpose**: Prevents attendance record manipulation
- **Lock Time**: Begins Monday 00:00 of current week
- **Exception**: Only administrators can modify current week

#### **Emergency Change Process:**
1. **Employee Action**: Contact direct supervisor immediately
2. **Supervisor Approval**: Get written/email authorization
3. **Admin Request**: Supervisor contacts system administrator
4. **Admin Modification**: Administrator updates schedule
5. **Notification**: Employee receives confirmation of changes
6. **Documentation**: Change reason recorded in system

#### **Weekly Reset System:**
- **Reset Time**: Every Monday at 12:00 AM (midnight)
- **Fresh Start**: New week allows full schedule modification
- **No Carry-Over**: Previous week's schedule doesn't auto-copy
- **Manual Setup**: Must manually set each week's schedule
- **Planning Window**: Best to set schedule by Sunday evening

### 👨‍💼 Admin Override Capabilities

#### **Administrator Powers:**
- **Unlimited Access**: Can modify any employee's schedule
- **No Time Restrictions**: Can change current, past, or future weeks
- **Immediate Effect**: Changes apply instantly
- **Bulk Operations**: Can update multiple employees simultaneously

#### **Employee Notification System:**
- **Automatic Alerts**: Employees notified of admin changes
- **Change Details**: Notification includes what was changed
- **Reason Field**: Admins can include reason for change
- **Acknowledgment**: Employees can acknowledge receipt

### 📋 Timetable Best Practices

#### **Planning Guidelines:**
- **Set by Sunday**: Complete next week's schedule before Monday
- **Consider Holidays**: Plan around company holidays and events
- **Consistent Patterns**: Maintain regular schedules when possible
- **Buffer Time**: Leave small gaps between slots for transitions

#### **Time Format Requirements:**
- **24-Hour Format**: Always use 09:00, 14:30, 17:00 format
- **Avoid Overlaps**: Ensure slots don't conflict with each other
- **Minimum Duration**: Each slot should be at least 1 hour
- **Break Consideration**: Account for lunch and break times

#### **Common Scheduling Mistakes:**
- **Overlapping Slots**: Two slots with conflicting times
- **Too Short Slots**: Slots less than 1 hour duration
- **No Break Time**: Back-to-back slots without breaks
- **Weekend Confusion**: Accidentally scheduling on non-work days

---

## 🚫 System Validations & Restrictions

### ⏰ Time-Based Validations

#### **Check-In Validations:**
- **Too Early**: Cannot check-in more than 1 hour before scheduled
- **Already Checked In**: Cannot check-in if already active session
- **No Schedule**: Cannot check-in without timetable set
- **Wrong Day**: Cannot check-in on non-scheduled days

#### **Check-Out Validations:**
- **Not Checked In**: Must have active check-in session
- **Too Early**: Cannot check-out before minimum hours worked
- **Invalid Time**: Check-out time must be after check-in time
- **System Error**: Prevents check-out during system maintenance

### 🔄 Duplicate Prevention System

#### **10-Minute Cooldown Rule:**
- **Purpose**: Prevents accidental duplicate entries
- **Application**: Both check-in and check-out attempts
- **Error Message**: "Please wait X minutes before trying again"
- **Override**: Only administrators can override cooldown

#### **Session Management:**
- **Single Session**: Only one active session per employee
- **Session Tracking**: System tracks current status
- **Status Display**: Clear indication of current state
- **Error Prevention**: Blocks conflicting actions

### 📊 Slot-Based System Rules

#### **Sequential Processing:**
- **Order Requirement**: Must complete slots in chronological order
- **Example**: Cannot start afternoon slot without completing morning
- **Validation**: System enforces proper sequence
- **Flexibility**: Can skip slots if not scheduled

#### **Multiple Slot Management:**
- **Independent Tracking**: Each slot tracked separately
- **Completion Status**: Shows which slots are complete
- **Remaining Work**: Displays upcoming scheduled slots
- **Daily Summary**: Combines all slots for daily totals

---

## 🔧 Troubleshooting

### ❌ Common Error Messages

#### **"Check-in window not open yet"**
- **Cause**: Attempting check-in more than 1 hour before scheduled time
- **Solution**: Wait until window opens (1 hour before scheduled time)
- **Example**: For 9:00 AM schedule, wait until 8:00 AM
- **Tip**: Check current time and scheduled time

#### **"You are already checked in"**
- **Cause**: Trying to check-in when already have active session
- **Solution**: Check current status, may need to check-out first
- **Verification**: Look for "Currently Checked In" status
- **Action**: Use check-out button to end current session

#### **"Multiple check-ins within 10 minutes not allowed"**
- **Cause**: Attempting check-in too soon after previous attempt
- **Solution**: Wait for cooldown period to expire
- **Prevention**: Ensure successful check-in before leaving page
- **Status Check**: Verify check-in was successful

#### **"No more scheduled slots for today"**
- **Cause**: All scheduled work slots are completed
- **Solution**: Contact administrator if additional work needed
- **Note**: System prevents unauthorized overtime
- **Alternative**: Admin can add additional slots if needed

#### **"Late check-in window has expired"**
- **Cause**: Attempting check-in more than 2 hours after scheduled time
- **Solution**: Contact administrator for manual attendance entry
- **Policy**: Extremely late arrivals require admin intervention
- **Documentation**: Provide reason to administrator

### 🔄 System Performance Issues

#### **Page Loading Problems:**
- **Clear Cache**: Clear browser cache and cookies
- **Refresh Page**: Use Ctrl+F5 for hard refresh
- **Different Browser**: Try alternative browser
- **Internet Check**: Verify stable internet connection

#### **Button Responsiveness:**
- **Wait Time**: Allow 3-5 seconds for system response
- **Single Click**: Avoid multiple rapid clicks
- **Page Refresh**: Refresh if buttons become unresponsive
- **Session Check**: Verify you're still logged in

### 📱 Mobile-Specific Issues

#### **Display Problems:**
- **Orientation**: Use landscape mode for better table viewing
- **Zoom Level**: Adjust zoom for optimal viewing
- **Browser**: Use updated mobile browser
- **App Mode**: Add to home screen for app-like experience

#### **Touch Interface:**
- **Tap Accuracy**: Ensure precise button taps
- **Scroll Issues**: Use two-finger scroll for tables
- **Keyboard**: Use numeric keyboard for time entry
- **Connection**: Ensure stable mobile data/WiFi

---

## 📞 Support & Escalation

### 🆘 When to Contact Administrator

#### **Immediate Contact Required:**
- Late check-in window expired (over 2 hours late)
- System errors preventing check-in/out
- Need to modify current week's schedule
- Attendance record corrections needed

#### **Standard Support Requests:**
- Questions about timetable setup
- Understanding overtime calculations
- Clarification on company policies
- Technical issues with system access

### 📧 Information to Provide

#### **For Technical Issues:**
- Your employee ID
- Exact error message received
- Time and date of issue
- Browser and device information
- Steps taken before error occurred

#### **For Schedule Changes:**
- Current schedule details
- Requested changes
- Reason for change
- Supervisor approval (if required)
- Preferred effective date

---

*This comprehensive guide covers all aspects of FSPro's attendance system. For company-specific policies or advanced configurations, consult your system administrator.*
